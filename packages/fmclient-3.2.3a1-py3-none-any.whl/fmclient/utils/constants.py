import os

import fmclient
from . import helper as hlp

# Version
LIB_VERSION = fmclient.__version__
LIB_NAME = 'FM Client'

# Available FM Servers
FM_HOSTS = [FM_HOST_FM := 'FM', FM_HOST_AHM := 'AHM']
FM_HOST_DEFAULT = FM_HOST_FM
FM_HOST_SERVERS = {
    FM_HOST_FM: "https://guarded-ridge-89710.herokuapp.com",
    FM_HOST_AHM: "https://fm-data.herokuapp.com"
}

# Set host for application
FM_HOST = os.environ.get('FM_HOST', FM_HOST_DEFAULT)
FM_HOST = FM_HOST if FM_HOST in FM_HOSTS else FM_HOST_DEFAULT

# Root URL
FM_ROOT = FM_HOST_SERVERS[FM_HOST]

API_PATH = "/api"
API_ROOT = FM_ROOT + API_PATH

# FM WS Endpoint
FM_WS_ROOT = FM_ROOT.replace('http', 'ws')
FM_WS_PATH = API_PATH + "/events"
FM_WS_SSL = hlp.str_to_bool(os.environ.get("FM_WS_SSL", "True"))

# Other API Endpoints
MARKETPLACE_URI = "/marketplaces/$id$"
MARKETPLACE_URL = API_ROOT + MARKETPLACE_URI

SESSIONS_URI = "/sessions"
SESSIONS_URL = API_ROOT + SESSIONS_URI

SESSION_URI = "/sessions/$id$"
SESSION_URL = API_ROOT + SESSION_URI

USERS_URI = "/users-json"
USERS_URL = API_ROOT + USERS_URI

HOLDINGS_EXPORT_URI = MARKETPLACE_URI + "/holdings/downloads?sessions=last"
HOLDINGS_EXPORT_URL = API_ROOT + HOLDINGS_EXPORT_URI
HOLDINGS_JSON_EXPORT_URI = MARKETPLACE_URI + "/holdings"
HOLDINGS_JSON_EXPORT_URL = API_ROOT + HOLDINGS_JSON_EXPORT_URI

HOLDINGS_IMPORT_URI = MARKETPLACE_URI + "/holdings/uploads"
HOLDINGS_IMPORT_URL = API_ROOT + HOLDINGS_IMPORT_URI

HOLDINGS_CSV_HEADER = "# holdings -- begin"
HOLDINGS_CSV_FOOTER = "# holdings -- end"

ORDERS_CSV_HEADER = "# orders -- begin"
ORDERS_CSV_FOOTER = "# orders -- end"

# Connection Configuration
ASYNCIO_MAX_THREADS = 2

# Agent Reporting and Monitoring Configuration
MONITOR_ORDER_BOOK_DELAY = 0.25

# WebSocket Communication Configuration
WS_MESSAGE_DELAY = 0.1
WS_ADDRESS = os.environ.get("BOT_WS_DOMAIN", "algohost.bmmlab.org")
WS_PORT = int(os.environ.get("BOT_WS_PORT", 443))
WS_SSL = hlp.str_to_bool(os.environ.get("BOT_WS_SSL", "True"))
WS_PATH = "/chat/stream/"
WS_SIMULATE = hlp.str_to_bool(os.environ.get("BOT_WS_SIMULATE", "False"))

import time
from datetime import datetime

import pytz


COMMENT = "#"
NEWLINE = "\n"
LOCAL_TIMEZONE = "Australia/Melbourne"
DATE_FORMAT = "%Y-%m-%dT%H:%M:%S.%f"
DATE_FORMAT_NO_MS = "%Y-%m-%dT%H:%M:%S"


def time_milli():
    return int(round(time.time() * 1000))


def string_to_date(date_string: str, date_format=None, timezone=None) -> datetime:
    tz = timezone if timezone else pytz.utc
    try:
        date = datetime.strptime(date_string, DATE_FORMAT)
    except ValueError:
        date = datetime.strptime(date_string, DATE_FORMAT_NO_MS)
    return date.replace(tzinfo=tz)


def to_local(date: datetime, local_timezone=None) -> datetime:
    timezone = pytz.timezone(local_timezone) if local_timezone else pytz.timezone(LOCAL_TIMEZONE)
    return date.astimezone(timezone)


def string_to_local_date(date_string: str, remote_timezone=None) -> datetime:
    return to_local(string_to_date(date_string, timezone=remote_timezone))


def clean_line(line):
    line = line.strip()
    if len(line):
        if line[0] == COMMENT:
            return ""
        if line[-1] == NEWLINE:
            return line[:-1]
    return line


def get_index(l: list, item):
    try:
        return l.index(item)
    except ValueError:
        return None


def clean_string(string):
    keepcharacters = ('-', '.', '_', '@')
    return "".join(c for c in string if c.isalnum() or c in keepcharacters).strip()


def str_shorten(string, length=10):
    """Returns a truncated version of string. Default length is 10"""
    return string if len(string) <= length else string[:length]


def str_to_bool(string: str):
    string = string.lower()
    if string == 'true':
        return True
    if string == 'false':
        return False
    raise ValueError(f"Cannot convert {string} to bool")


def parametrise(string, sep='_'):
    return string.replace('-', sep) if isinstance(string, str) else string

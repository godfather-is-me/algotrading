"""
Module consisting of the base class for trading agents.

In order to interact with Flex-e-Markets based servers, base Agent must be sub-classed with concrete implementation
of necessary methods.
"""

import asyncio
import concurrent.futures as ft
import functools
import logging
import logging.config
import sys
import threading
import traceback
from abc import ABC, abstractmethod
from typing import List, Union

import coloredlogs
from aiohttp import client_exceptions as aiohttp_exceptions
from deprecated import deprecated

from .. import __version__ as fm_version
from ..data.message import MessageType
from ..data.orm.holding import Holding
from ..data.orm.market import Market
from ..data.orm.marketplace import Marketplace
from ..data.orm.order import Order
from ..data.orm.session import Session, SessionState
from ..fmio.net.fmapi.rest.auth import Auth as FMAuth
from ..fmio.net.fmapi.rest.request import Request, RequestMethod
from ..fmio.net.fmapi.ws.client import WebSocketClient, IncomingMessageType
from ..fmio.net.hosting.ws.client import AgentWebsocketClient
from ..utils import constants as cons, helper as hlp
from ..utils.constants import FM_HOST
from ..utils.logging import FMLogger


class Agent(ABC):
    """
    This is the main (abstract) class that will provide the required functionality to build custom trading agents.
    The class provides automatic subscription to order book, holding and marketplace updates.
    In addition, the class also provides websocket communication.
    """

    __subclass = None

    def __init__(self, account, email, password, marketplace_id, name=None, enable_ws=True):
        """
        Note: Do not include any method that uses asyncio here. This creates a conflict with upload on algohost.

        :param account: FM account
        :param email:  FM email
        :param password: FM password
        :param marketplace_id: Id of marketplace
        :param name: name of the bot
        """
        self._account = account
        self._email = email
        self._password = password
        self._marketplace_id = marketplace_id
        self._name = name if name else email
        self._enable_ws_comm = enable_ws
        self._logger = None
        self._setup_logging()  # This should be init as soon as basic information on an agent is available

        self._loop = None
        self._description = None
        self._stop = False
        self._initialised = False
        self._enable_user_communication = False

        self._incoming_message_queue = None
        self._outgoing_order_queue = None
        self._current_session = None
        self._holdings = None
        self._ws_ah = None
        self._ws_fm = None

        self._monitor_count = 0  # For LAT_TEST ONLY
        self._outgoing_order_count = {}
        self._session_semaphore = threading.Semaphore()  # A semaphore to manage access to session with single access
        self._user_tasks = []

    def __init_subclass__(cls, *args, **kwargs):
        Agent.__subclass = cls

    # ---- SETUP METHODS ----
    def _safely_call_method(self, f: Union[callable, functools.partial]) -> None:
        """
        Wraps and calls a method/function in a try/except block

        :param f: callable to call
        :return: None
        """
        try:
            f()
        except:
            f_name = f.func.__name__ if isinstance(f, functools.partial) else f.__name__
            self._logger.error(f"Exception in {Agent.__subclass.__name__}.{f_name}() method. "
                               f"Run with DEBUG for details.")
            self._logger.debug(traceback.format_exc())

    def _login(self):
        """
        FMAuth is a singleton and needs to be instantiated before any request is performed.
        #TODO: In case of errors, check if FMAuth was garbage collected.

        :return:
        """
        FMAuth(self._account, self._email, self._password)  # Only need to login once

    def _init_communication(self):
        if self.enable_user_communication:
            self._send_ws_message("activate communication", msg_type=MessageType.CUSTOM)

    def _setup_logging(self):
        """
        Setup the logger with specific format.

        :return:
        """
        default_config = {
            'agent_name': self._email,
            'marketplace_id': str(self._marketplace_id)
        }

        # Name should be agent.<agent.name> format
        self._logger = FMLogger(default_config=default_config).get_logger(hlp.str_shorten(self.name, 15), "agent")
        try:
            self._log_file = FMLogger().get_logger("agent").handlers[0].baseFilename
        except IndexError:
            self._log_file = ""
        try:
            coloredlogs.DEFAULT_FIELD_STYLES['msecs'] = coloredlogs.DEFAULT_FIELD_STYLES['asctime']
            # noinspection PyProtectedMember
            coloredlogs.install(logger=self._logger, milliseconds=True,
                                fmt=FMLogger().get_logger("agent").handlers[0].formatter._fmt)
        except IndexError:
            coloredlogs.install(logger=self._logger, milliseconds=True)

    def _get_event_loop(self):
        """
        If the agent is not running in the main thread, create a new loop and associate it with asyncio.

        :return: Asyncio loop
        """
        if self._loop:
            return self._loop

        try:
            loop = asyncio.get_event_loop()
        except RuntimeError as re:
            loop = None
        if loop is None:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        return loop

    def _set_asyncio_properties(self):
        """
        Sets the asyncio properties, e.g., the thread pool executor.

        :return:
        """
        executor = ft.ThreadPoolExecutor(max_workers=cons.ASYNCIO_MAX_THREADS)
        self._loop.set_default_executor(executor)

    # ---- AGENT INIT, START AND CONTROL METHODS ----
    def _initialise(self):
        self._loop = self._get_event_loop()
        self._set_asyncio_properties()
        self._outgoing_order_queue = asyncio.Queue()
        self._incoming_message_queue = asyncio.Queue()

        # self._logger.setLevel(logging.DEBUG)

        try:
            # Attempt login
            self._login()

            # Setup Algohost WebSocket Client
            if self._enable_ws_comm:
                self._ws_ah = AgentWebsocketClient(self._name, self._account, self._email, self._password,
                                                   self._marketplace_id, cons.WS_ADDRESS, cons.WS_PORT, cons.WS_PATH,
                                                   self._incoming_message_queue, ssl=cons.WS_SSL)
                self._ws_ah.setup()

            # Fetch the essential marketplace information
            self.inform(f"Requesting initial information for marketplace `{self._marketplace_id}`")
            self._get_marketplace_info()

            # Setup FM WebSocket Client
            self._ws_fm = WebSocketClient(self._name, cons.FM_WS_ROOT, cons.FM_WS_PATH, self._marketplace_id,
                                          self._incoming_message_queue,
                                          ssl=True)
            self._ws_fm.setup()

        except (aiohttp_exceptions.ClientConnectorCertificateError,):
            self._logger.debug(traceback.format_exc())
            self._logger.error("SSL Certificate error while connecting to FM Servers. "
                               "Check Python™ certificate installation documentation in FM manual.")
        except (aiohttp_exceptions.ClientConnectionError, ConnectionError):
            self._logger.debug(traceback.format_exc())
            self._logger.error(f"Unable to log into {FM_HOST} Servers or establish WebSocket connections")
        except KeyboardInterrupt:
            self._logger.error("User interrupt received during initialisation.")
        else:
            self._initialised = True
        finally:
            if self._initialised:
                # Inform the trading agent that initialization is complete.
                self.inform("Initialisation complete. Received marketplace information.")
                self._safely_call_method(self.initialised)
                self._init_communication()

            else:
                self._logger.debug(traceback.format_exc()) if any(sys.exc_info()) else None
                self._logger.warning('Initialisation failed. Exiting!')
                logging.shutdown()
                exit(1)

    def _start(self):
        """
        Start the algorithm execution by running the essential tasks in a loop.
        Each co-routine is executed in a single asyncio loop.

        :return:
        """
        try:
            asyncio_tasks = []

            # schedule and user defined tasks
            for task in self._user_tasks:
                asyncio_tasks.append(task)

            # task for the order processor
            asyncio_tasks.append(self._process_order_queue())

            # tasks for the handling incoming messages
            asyncio_tasks.append(self._process_incoming_messages())

            # run the loop
            try:
                # return exceptions True to prevent error in one task from failing all other tasks
                self._loop.run_until_complete(asyncio.gather(*asyncio_tasks, return_exceptions=True))
            except (aiohttp_exceptions.ServerConnectionError, aiohttp_exceptions.ServerDisconnectedError):
                self.error("Cannot connect to server!")
            except asyncio.TimeoutError:
                self.error("The connection to server timed out and now I have to die!")

        except KeyboardInterrupt:
            self.error("Oops. Keyboard Interrupt received from user.")
        finally:
            self.inform('Shutting Down')
            self.stop_after_wait(2)
            logging.shutdown()
            self._loop.close()

    def run(self):
        """This is the main method that initialises and starts a trading agent. This method starts market interaction"""
        self._logger.info(f"Using fmclient version: {fm_version}")
        self._initialise()
        self._safely_call_method(self.pre_start_tasks)
        self._start()

    def stop_after_wait(self, wait_time):
        """
        Stop the algorithm execution in a graceful manner.
        Each perpetual task should by default check for the stop variable.

        :param wait_time: time to wait (in seconds) before stopping
        :return:
        """

        assert wait_time > 0, "wait time for stopping must be greater than 0"

        # set the stop variable to be true
        async def _wait_stop():
            self.stop = True
            await asyncio.sleep(wait_time)

        task = self._loop.create_task(_wait_stop())
        if not self._loop.is_running():
            self._loop.run_until_complete(asyncio.gather(task))
        else:
            asyncio.gather(task)

    def execute_periodically(self, func: callable, sleep_time: int):
        """
        Register a co-routine for the given function to be executed perpetually with a delay.

        :param func: The function to be executed.
        :param sleep_time: The time to wait before the next execution (at least 1 second)

        :return:
        """
        assert sleep_time >= 1
        self.execute_periodically_variably_conditionally(func, lambda: sleep_time, lambda: True)

    def execute_periodically_variably(self, func: callable, sleep_time_func: callable):
        """
        Register a co-routine for the given function to be executed perpetually with a delay.

        :param func: The function to be executed.
        :param sleep_time_func: A callable that returns time to wait before next execution (at least 1 second)

        :return:
        """
        self.execute_periodically_variably_conditionally(func, sleep_time_func, lambda: True)

    def execute_periodically_conditionally(self, func: callable, sleep_time: int, condition: callable):
        """
        Register a co-routine for the given function to be executed conditionally and perpetually with a delay

        :param func: The function to be executed.
        :param sleep_time: The time to wait before the next execution (at least 1 second)
        :param condition: A callable that returns whether this function should be executed

        :return:
        """
        assert sleep_time >= 1
        self.execute_periodically_variably_conditionally(func, lambda: sleep_time, condition)

    def execute_periodically_variably_conditionally(self, func: callable, sleep_time_func: callable,
                                                    condition: callable):
        """
        Register a co-routine for the given function to be executed conditionally and perpetually with a variable delay

        :param func: The function to be executed.

        :param sleep_time_func: A callable that returns time to wait before next execution (at least 1 second)

        :param condition: A callable that returns whether this function should be executed

        :return:
        """

        async def _execute():
            while not self.stop:
                self._safely_call_method(func) if condition() else None
                await asyncio.sleep(sleep_time_func() or 1)

        self._user_tasks.append(_execute())

    def _get_marketplace_info(self, call_back=None):
        """
        Get the details of the assigned marketplace.
        This method retrieves the markets under the marketplace.

        :param call_back: A callable to receive marketplace info dictionary
        :return:
        """
        marketplace_url = cons.MARKETPLACE_URL.replace("$id$", str(self._marketplace_id))

        def _handle_mp_info(content):
            self.debug("Fetching Marketplace info")
            Marketplace(content['id'], content)

        def _handle_markets_info(content):
            markets = content["_embedded"]["markets"]
            _m_pt_tasks = []

            for market in markets:
                mkt = Market(market['id'], market)  # Creates singleton objects of Markets
                self._outgoing_order_count[mkt] = 0
                _m_pt_tasks.append(_get_private_traders(mkt))

            # check if a loop exists and call the get_mp_info method.
            if not self._loop.is_running():
                for _t in _m_pt_tasks:
                    self._loop.run_until_complete(_t)
            else:
                return asyncio.gather(*_m_pt_tasks)

        async def _get_private_traders(mkt):
            try:
                await Request(mkt.url_private_traders, lambda x: mkt.update_attr('private_traders', x)).perform()
            except (AttributeError, TypeError):
                pass

        async def get_mp_info():
            try:
                await Request(marketplace_url, _handle_mp_info).perform()
                # Request all markets in this marketplace
                await Request(Marketplace(self._marketplace_id).url_markets, _handle_markets_info).perform()
            except Exception as e:
                raise ConnectionError(e)

        # check if a loop exists and call the get_mp_info method.
        if not self._loop.is_running():
            self._loop.run_until_complete(get_mp_info())
        else:
            task = self._loop.create_task(get_mp_info())
            if call_back is not None:
                task.add_done_callback(call_back)
            return asyncio.gather(task)

    async def _process_order_queue(self):
        """
        A task to send orders from the queue to the exchange server. On acceptance and rejection of orders the subclass
        is notified. The subclass must override order_accepted and order_rejected abstract methods.

        :return: Asyncio co-routine
        """

        def order_accepted(info):
            self._safely_call_method(functools.partial(self.order_accepted, Order(info['id'], info)))

        def order_rejected(info):
            self._safely_call_method(functools.partial(self.order_rejected, info, order))

        # TODO: Candidate for modularisation and code extraction
        while not self.stop:
            # if self.is_session_active():
            while not self._outgoing_order_queue.empty():
                try:
                    order = self._outgoing_order_queue.get_nowait()

                    self.debug(f"Order Queued: {self._outgoing_order_count}")
                    await Request("/orders", order_accepted, error_callback_func=order_rejected,
                                  request_method=RequestMethod.POST, data=order.encode()).perform()
                    self.debug(f"  Order Sent: {self._outgoing_order_count}")

                    self._outgoing_order_count[order.market] -= 1
                except:
                    self._logger.error(traceback.format_exc())
            # else:
            #     if self._outgoing_order_queue.qsize() > 0:
            #         self.warning("I cannot send orders to an inactive session.")
            await asyncio.sleep(cons.MONITOR_ORDER_BOOK_DELAY)

    async def _process_incoming_messages(self):
        """
        A task to process incoming messages to the trading agent.
        These messages normally come from robot hosting web-interface

        :return: Asyncio co-routine
        """
        while not self.stop:
            while not self._incoming_message_queue.empty():
                # TODO: Redo this section. Message handling is ugly and with hardcoded values
                # TODO: Add parsing of incoming WS messages from FM
                message = self._incoming_message_queue.get_nowait()

                if "source" in message.keys() and message["source"] == "robot":
                    pass
                elif "command" in message.keys() and message["command"] == "stop":
                    self.stop = True
                elif "source" in message.keys() and message["source"] == "user" and self.enable_user_communication:
                    self._safely_call_method(functools.partial(self.respond_to_user, message['message']))
                elif any(x in message for x in list(IncomingMessageType)):
                    self._logger.debug(f"{FM_HOST} MSG: {message}")
                    for k, v in message.items():
                        func = getattr(self, f"_on_{k.name.lower()}", None)
                        if func and callable(func):
                            func(v)

                # Work on this and clean the output. It duplicates messages on web and here, via websockets
                if 'message' in message and 'source' in message and message['source'].lower() != 'robot':
                    self.inform("Received message: " + str(message["message"]), ws=False)
                # TODO Post custom order to the server, define domain language
            await asyncio.sleep(cons.WS_MESSAGE_DELAY)

    def _send_ws_message(self, message, msg_type=MessageType.INFO):
        """
        Just a wrapper around the websocket message sending functionality.

        :param message: message string
        :param msg_type: type of message
        :return:
        """
        self._ws_ah.send_message(message, str(msg_type.name)) if self._enable_ws_comm else None

    def _on_session_update(self, session_json):
        self._logger.debug(session_json)
        old_state = self.current_session.state if self.current_session else None

        with self._session_semaphore:
            self._current_session = Session(session_json["id"], session_json)
            self.inform(f"Session: {self._current_session}")

        if old_state != self.current_session.state:
            self._logger.debug(f"Session state changed. Open? {self.current_session.is_open}")
            if self.current_session.is_open and old_state is SessionState.CLOSED:
                Order.clear_all()
            self._safely_call_method(functools.partial(self.received_session_info, self.current_session))

    def _on_holding_update(self, holding_json):
        self._logger.debug(holding_json)
        try:
            self._holdings = Holding(holding_json)
        except (AttributeError, ValueError, KeyError):
            self.error("Error creating holding")
            self._logger.debug(traceback.format_exc())

        self._safely_call_method(functools.partial(self.received_holdings, self._holdings))

    def _on_orders_update(self, order_json):
        self._logger.debug(order_json)
        _orders = []  # TODO: Refactor
        for _order in order_json:
            try:
                _orders.append(Order(_order['id'], _order))
            except:
                self._logger.debug(traceback.format_exc())
                self.error("Error parsing incoming order data. Check debug log for more info.")

        self._safely_call_method(functools.partial(self.received_orders, _orders))

    # -- Methods for subclasses and objects for various external tasks
    def send_message_to_user(self, message):
        self._send_ws_message(message, MessageType.COMM)

    def my_info(self):
        """
        Send the algorithm name and associated marketplace id.

        :return: Algorithm name:marketplace id
        """
        return f"{self._name}:{str(self._marketplace_id)}"

    def thread_info(self):
        """
        Print the number of thread count and names of active threads.

        :return:
        """
        print(f"{self}:{threading.active_count()}")
        for t in threading.enumerate():
            print(t.getName())

    def is_session_active(self):
        return self.current_session.is_open

    def should_continue(self):
        return not self.stop

    def is_session_active_and_can_continue(self):
        return self.is_session_active() and self.should_continue()

    @deprecated(version='3.2.2', reason='This method is now called `pending_outgoing_orders_count`')
    def get_pending_orders(self, market: Market):
        """
        Return the number of pending orders in the order queue for a given market.

        .. versionchanged: 3.2.2
            Renamed to pending_outgoing_orders_count

        :param market: market for which pending orders are requested
        :return: Number of orders waiting to be sent
        """
        return self.pending_outgoing_orders_count(market)

    def pending_outgoing_orders_count(self, market: Market):
        """
        Return the number of pending orders in the order queue for a given market.

        :param market: market for which pending orders are requested
        :return: Number of orders waiting to be sent
        """
        assert isinstance(market, Market)
        return self._outgoing_order_count[market]

    def send_order(self, order: Order):
        """
        Send an order to the exchange.

        :param order:
        """
        assert isinstance(order, Order)
        self._outgoing_order_queue.put_nowait(order)
        self._outgoing_order_count[order.market] += 1

    @deprecated(version='3.0.0', reason='This method is no longer in use. Use `Order` class instead.')
    def get_trades(self, market: Market):  # TODO: WS or current REST?
        """
        Request trades for a market from the exchange and calls the callback with the list of such orders.

        :param market: Market for which trades are being requested
        :return:
        """

        self.inform(f"Requesting current trades for market {market} in marketplace {self._marketplace_id}")

        def handle_trades_info(order_json):
            trades = []  # TODO: Refactor
            try:
                trades = [Order(_order['id'], _order) for _order in order_json]
            except:
                self._logger.debug(traceback.format_exc())
                self.error("Error parsing incoming traded order data. Run with DEBUG for details.")
            finally:
                self._safely_call_method(functools.partial(self.received_trades, trades, market))

        url = market.url_orders_completed_json
        params = {"size": 10000, 'sessionId': self.current_session.fm_id}
        task = self._loop.create_task(Request(url, callback_func=handle_trades_info, params=params).perform())
        asyncio.gather(task)

    # ----- Logging Methods -----
    def inform(self, msg, ws=True):
        """
        Send the given message to relevant targets. For example, logging and websocket.

        :param msg:
        :param ws: True will send message on websockets as well
        :return:
        """
        self._logger.info(msg)
        self._send_ws_message(msg, MessageType.INFO) if ws and self._logger.isEnabledFor(logging.INFO) else None

    def error(self, msg, ws=True):
        self._logger.error(msg)
        if ws and self._logger.isEnabledFor(logging.ERROR): self._send_ws_message(msg, MessageType.ERROR)

    def debug(self, msg, ws=True):
        self._logger.debug(msg)
        if ws and self._logger.isEnabledFor(logging.DEBUG): self._send_ws_message(msg, MessageType.DEBUG)

    def warning(self, msg, ws=True):
        self._logger.warning(msg)
        if ws and self._logger.isEnabledFor(logging.WARNING): self._send_ws_message(msg, MessageType.WARN)

    @property
    def current_session(self) -> Session:
        with self._session_semaphore:
            return self._current_session

    @property
    def description(self):
        return self._description

    @description.setter
    def description(self, value):
        self._description = value

    @property
    def name(self):
        return str(self._name)

    @name.setter
    def name(self, value):
        self._name = value

    @property
    def stop(self):
        return self._stop

    @stop.setter
    def stop(self, value):
        if not self._stop:
            self.inform("I have been asked to stop! 😔")
            self._stop = bool(value)
            if self._enable_ws_comm:
                self._ws_ah.stop = bool(value)
            self._ws_fm.stop = bool(value)

    @property
    def marketplace(self) -> Marketplace:
        """
        Current Marketplace object

        .. versionadded: 3.3.0
            Added new property to return the current Marketplace object

        :return:
        """
        return Marketplace(self._marketplace_id)

    @property
    def markets(self):
        return Market.all()

    @property
    def holdings(self) -> Holding:
        return self._holdings

    @property
    def log_file(self):
        return self._log_file

    @property
    def enable_user_communication(self):
        return self._enable_user_communication

    @enable_user_communication.setter
    def enable_user_communication(self, value):
        self._enable_user_communication = value

    # ---- Abstract Methods for Subclasses to make concrete ---
    @abstractmethod
    def initialised(self):
        """
        Called after agent initialisation is complete

        :return:
        """
        self.error("Method `initialised` not implemented.")
        raise NotImplementedError

    @abstractmethod
    def order_accepted(self, order: Order):
        """
        Called when an submitted order is accepted.

        :param order: Order that was submitted to the server
        :return:
        """
        self.error("Method `order_accepted` not implemented.")
        raise NotImplementedError

    @abstractmethod
    def order_rejected(self, info: dict, order: Order):
        """
        Called when a submitted order is rejected.

        :param info: Error information returned by the server
        :param order: Order that was submitted to the server
        :return:
        """
        self.error("Method `order_rejected` not implemented.")
        raise NotImplementedError

    @abstractmethod
    def received_orders(self, orders: List[Order]):
        """
        This method is called when orders are received from FM

        :param orders: List of Orders received from FM via WS
        :return:
        """
        self.error("Method `orders_received` not implemented.")
        raise NotImplementedError

    @abstractmethod
    def received_holdings(self, holdings: Holding):
        """
        Called when holdings information is received from the exchange.
        This method should be overridden by the implementing sub-class.

        :param holdings:
        :return:
        """
        self.error("Method `received_holdings` not implemented.")
        raise NotImplementedError

    @abstractmethod
    def received_session_info(self, session: Session):
        """
        Called when marketplace information is received from the exchange.

        :param session:
        :return:
        """
        self.error("Method `received_session_info` not implemented.")
        raise NotImplementedError

    @abstractmethod
    def pre_start_tasks(self):
        """
        The sub-classed trading agent should override this method to perform any task or schedule tasks
        before Agent starts interacting in the marketplace

        :return:
        """
        self.warning("Method `pre_start_tasks` not implemented. No pre-start tasks scheduled.")
        raise NotImplementedError

    # @abstractmethod
    def received_trades(self, orders: List[Order], market: Market = None):
        """
        Called when completed orders are sent by the exchange.

        :param orders: List of traded orders
        :param market: Market for which trades were received

        :return:
        """
        self.error("Method `received_trades` not implemented.")
        raise NotImplementedError

    # @abstractmethod
    def respond_to_user(self, message: str):
        """
        Called when marketplace information is received from the exchange.

        :param message: Incoming message from user
        :return:
        """
        self.error("User communication is enabled but method `respond_to_user` not implemented.")
        raise NotImplementedError

"""
Order module for order objects from API
"""
from __future__ import annotations

import copy
from datetime import datetime
from enum import Enum
from typing import Dict, Tuple, List

from fmclient.data.orm.market import Market
from fmclient.data.orm.marketplace import Marketplace
from fmclient.data.orm.session import Session
from fmclient.data.orm.user import User
from fmclient.utils.helper import string_to_local_date, DATE_FORMAT


class OrderSide(Enum):
    BUY = 1
    SELL = -1


class OrderType(Enum):
    CANCEL = 0
    LIMIT = 1


class Order(object):
    """
    An existing or new Order in the Marketplace.
    In order to create a new Order, use the :py:classmethod:`Order.create_new()` class method.

    .. versionchanged: 3.1.0
        Order class now supports price-time priority comparison.
        Traded orders have least/most priority on Buy/Sell side.

    .. Note::
         *  This class does **not** support :py:func:`deepcopy` from Python's :py:module:`copy`
            module.
         *  A value of 0 for consumer_id signifies a split order
    """

    fm_id: int
    order_type: OrderType
    order_side: OrderSide
    units: int
    price: int
    original_id: int
    supplier_id: int
    consumer_id: int
    mine: bool
    symbol: str
    owner_or_target: str
    owner: User
    ref: str
    marketplace: Marketplace
    market: Market
    session: Session
    session_original: Session
    date_created: datetime
    date_last_modified: datetime

    __instances_by_id = {}
    __fields = {
        'id': ('fm_id', int),
        'type': ('order_type', lambda x: OrderType[x]),
        'side': ('order_side', lambda x: OrderSide[x]),
        'units': ('units', int),
        'price': ('price', int),
        'original': ('original_id', int),
        'supplier': ('supplier_id', int),
        'consumer': ('consumer_id', int),
        'mine': ('mine', bool),
        'symbol': ('symbol', str),
        'ownerTarget': ('owner_or_target', lambda x: x and str(x)),
        'ownerId': ('owner', lambda x: x and User(x)),
        'clientDescription': ('ref', lambda x: x and str(x)),
        'marketplaceId': ('marketplace', Marketplace),
        'marketId': ('market', Market),
        'sessionId': ('session', Session),
        'originalSessionId': ('session_original', Session),
        'createdDate': ('date_created', string_to_local_date),
        'lastModifiedDate': ('date_last_modified', string_to_local_date),
    }
    __field_validations = {
        'units': lambda x: (isinstance(x, int) and x >= 0, f"must be an `int` and >= 0, not `{type(x).__name__}`"),
        'price': lambda x: (isinstance(x, int) and x >= 0, f"must be an `int` and >= 0, not `{type(x).__name__}`"),
        'order_side': lambda x: (isinstance(x, OrderSide), f"must be of type `{OrderSide}`, not `{type(x).__name__}`"),
        'order_type': lambda x: (isinstance(x, OrderType), f"must be of type `{OrderType}`, not `{type(x).__name__}`"),
        'market': lambda x: (isinstance(x, Market), f"must be of type `{Market}`, not `{type(x).__name__}`"),
    }
    __fields_reverse = {
        'fm_id': ('id', lambda x: x or -1),
        'original_id': ('original', lambda x: x or -1),
        'supplier_id': ('supplier', lambda x: x or -1),
        'consumer_id': ('consumer', lambda x: x or None),
        'mine': ('mine', lambda x: bool(x)),
        'order_type': ('type', lambda x: x and x.name),
        'order_side': ('side', lambda x: x and x.name),
        'units': ('units', lambda x: x and int(x)),
        'price': ('price', lambda x: x and int(x)),
        'owner_or_target': ('ownerTarget', lambda x: x),
        'ref': ('clientDescription', lambda x: x and str(x)),
        'marketplace': ('marketplaceId', lambda x: x and x.fm_id),
        'market': ('marketId', lambda x: x and x.fm_id),
        'symbol': ('symbol', lambda x: x and str(x)),
        'date_created': ('createdDate', lambda x: x and x.strftime(DATE_FORMAT)),
        'date_last_modified': ('lastModifiedDate', lambda x: x and x.strftime(DATE_FORMAT)),
    }

    __enabled_attrs = set([_[0] for _ in __fields.values()])
    _fields = tuple(__enabled_attrs)
    _field_defaults = {}

    # Add additional attributes
    __enabled_attrs.update('_id _new _locked _original_dict'.split())
    _locked = False  # Relevant only for objects but not on class, however, it is required
    _new = False
    __print_fields = 'fm_id mine order_side units price market order_type is_pending'.split()

    def __new__(cls, id_, options: dict = None) -> Order:
        obj = super().__new__(cls)
        obj._locked = False
        obj._new = True
        obj._id = id_
        obj._original_dict = options
        obj.ref = None  # Just in case robot does not set it

        if id_:
            if id_ not in cls.__instances_by_id:
                if options:
                    for option, value in options.items():
                        if option in cls.__fields:
                            attr, type_ = cls.__fields[option]
                            try:
                                obj.__setattr__(attr, type_(value))
                            except:
                                obj.__setattr__(attr, None)

                    obj._new = False
                    obj._locked = True
                    cls.__instances_by_id[id_] = obj
            else:
                # We have this Order with us. Has it been updated? Currently performing naive update
                obj = cls.__instances_by_id[id_]
                if options:
                    # Unlock the object
                    obj.__dict__['_locked'] = False

                    # Update the values
                    for option, value in options.items():
                        if option in cls.__fields:
                            attr, type_ = cls.__fields[option]
                            try:
                                obj.__setattr__(attr, type_(value))
                            except:
                                pass  # Don't overwrite existing values in case of failure

                    # Lock it back
                    obj._locked = True

        try:
            return cls.__instances_by_id[id_]
        except KeyError:
            if id_ is None:
                for _field, _ in cls.__fields.values():
                    obj.__setattr__(_field, None)
                obj._new = False
                return obj
            else:
                raise ValueError(f"Order({id_}) does not exist in this marketplace")

    def __copy__(self) -> Order:
        _o = Order.create_new(self.market)
        for attr in self.__fields_reverse.keys():
            setattr(_o, attr, getattr(self, attr, None))
        return _o

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Order):
            return False
        if self.fm_id:
            return self.fm_id == other.fm_id and self.order_type == other.order_type  # CANCEL order has same fm_id
        return super().__eq__(other)

    def __lt__(self, other):
        """
        .. versionadded: 3.1.0
        """
        if not isinstance(other, Order):
            raise NotImplemented  # In Python 3.9 this will change to TypeError

        # Traded BUY is least and SELL is NOT
        if not self.is_pending:
            return self.order_side is OrderSide.BUY

        return (self.order_type == other.order_type and  # Orders must be of same OrderType
                (self.price < other.price or  # Order price is strictly less than other
                 (self.price == other.price and  # Otherwise, at same price, there is time priority based on OrderSide
                  (self.date_created < other.date_created if self.order_side is OrderSide.SELL else
                   self.date_created > other.date_created))))

    def __le__(self, other):
        if not isinstance(other, Order):
            raise NotImplemented  # In Python 3.9 this will change to TypeError
        return self.__lt__(other) or self.__eq__(other)

    def __gt__(self, other):
        if not isinstance(other, Order):
            raise NotImplemented  # In Python 3.9 this will change to TypeError

        # Traded SELL is highest and BUY is NOT
        if not self.is_pending:
            return self.order_side is OrderSide.SELL

        return (self.order_type == other.order_type and  # Orders must be of same OrderType
                (self.price > other.price or  # Order price is strictly greater than other
                 (self.price == other.price and  # Otherwise, at same price, there is time priority based on OrderSide
                  (self.date_created > other.date_created if self.order_side is OrderSide.SELL else
                   self.date_created < other.date_created))))

    def __ge__(self, other):
        if not isinstance(other, Order):
            raise NotImplemented  # In Python 3.9 this will change to TypeError
        return self.__gt__(other) or self.__eq__(other)

    def __hash__(self) -> int:
        # Squaring creates a wide enough range to prevent clashes; also necessary for sorting(!)
        return hash(self._id**2)  # _id instead of fm_id because _id shouldn't be normally set by users

    def __str__(self) -> str:
        try:
            whose = 'Mine' if self.mine else 'Others'
            output = (f"{self.fm_id},{whose},{self.order_side.name},{self.units}@{self.price},{self.market.item}"
                      f",{self.order_type.name}")
            # output += ";".join(['', str(self.date), str(self.mod_date)])
            # output += f":TD:{self.mod_date - self.date}"
        except:
            output = ','.join([f"{f}:{str(getattr(self, f))}" for f in self.__print_fields if hasattr(self, f)])

        output += f",REF:'{self.ref}'" if self.ref else ''
        pvt_dir = 'TO' if self.fm_id is None or self.mine else 'FROM'
        output += f",PVT_{pvt_dir}:{self.owner_or_target}" if self.owner_or_target else ''

        return f"Order({output})"

    def __repr__(self):
        return self.__str__()

    def __getattr__(self, attr):
        if attr not in self.__enabled_attrs or attr not in self.__dict__:
            raise AttributeError(f"Order object does not have attribute `{attr}`")

        # Fetch a remote value here and return it
        return self.__dict__[attr]

    def __setattr__(self, attr, value):
        if attr not in self.__enabled_attrs:
            raise AttributeError(f"Order object does not support attribute `{attr}`")

        if self._locked:
            raise TypeError("'Order' object cannot be modified after creation")

        # Perform any validations
        if not self._new and attr in self.__field_validations:
            validate = self.__field_validations[attr]
            if callable(validate) and not validate(value)[0]:
                raise ValueError(f"Cannot set {attr} to {value} because it {validate(value)[1]}")

        # Set a remote value here
        self.__dict__[attr] = value

    @property
    def is_private(self) -> bool:
        try:
            return self.owner_or_target is not None
        except AttributeError:
            return False

    @property
    def is_pending(self) -> bool:
        """
        An active order is one that has not been consumed or split

        :return: True or False
        """
        try:
            return self.consumer_id is None
        except AttributeError:
            return False

    @property
    def is_split(self) -> bool:
        """
        An order that was split to fulfil trades and create remaining unfulfilled child orders
        A split order is generally also traded.

        :return: True or False
        """
        try:
            return not self.is_pending and self.consumer_id == 0
        except AttributeError:
            return False

    @property
    def is_partial(self) -> bool:
        """
        A partial order is one which was created from a split order for either fulfilling a partial trade or creating
        balance order.

        :return: True or False
        """
        try:
            return self.fm_id != self.original_id
        except AttributeError:
            return False

    @property
    def is_balance(self) -> bool:
        """
        An unfulfilled order that was created as a result of partial trade of a previously split order for remaining
        units of such a previously split order

        :return: True or False
        """
        try:
            return self.is_pending and self.is_partial
        except AttributeError:
            return False

    @property
    def is_consumed(self) -> bool:
        """
        Whether an order has been consumed, which happens when it is traded or cancelled, but not a split order itself

        :return: True or False
        """
        try:
            return not self.is_pending and self.consumer_id > 0
        except AttributeError:
            return False

    @property
    def is_cancelled(self) -> bool:
        """
        A cancelled order is one for which either its own or its consuming order's order type is CANCEL

        :return: True or False
        """
        try:
            return self.is_consumed and (self.order_type is OrderType.CANCEL or
                                         self.consumer.order_type is OrderType.CANCEL)
        except AttributeError:
            return False

    @property
    def has_traded(self) -> bool:
        try:
            return self.is_consumed and not self.is_cancelled
        except AttributeError:
            return False

    @property
    def is_partial_trade(self) -> bool:
        """
        A traded order that was created from a split order
        """
        try:
            return self.has_traded and self.is_partial
        except AttributeError:
            return False

    @property
    def traded_order(self) -> Order:
        try:
            return self.consumer if self.has_traded else None
        except (AttributeError, ValueError):
            pass

    @property
    def consumer(self) -> Order:
        try:
            return Order(self.consumer_id) if self.consumer_id else None
        except (AttributeError, ValueError):
            pass

    def traded_with(self, other: Order) -> bool:
        if not isinstance(other, Order):
            return False
        _res = (self.consumer_id == other.fm_id and other.consumer_id == self.fm_id
                and self.order_side != other.order_side and self.price == other.price)
        return _res

    def encode(self) -> dict:
        """
        Encode an Order object into dictionary for upstream API
        :return: dict containing keys that are understood by upstream API
        """
        order_dict = {}

        for attr, enc in self.__fields_reverse.items():
            key, type_ = enc
            if callable(type_):
                order_dict[key] = type_(getattr(self, attr, None))

        # Handles CANCEL orders specially; Split orders don't need their original to be set to id while cancelling
        if self.order_type is OrderType.CANCEL and not self.original_id:
            order_dict['original'] = order_dict['supplier'] = self.fm_id

        return order_dict

    def _validate_units(self, units):
        pass

    def _validate_price(self, price_):
        pass

    @classmethod
    def create_new(cls, market: Market = None) -> Order:
        """
        Creates a new order

        :param market: an optional Market object
        :return: a new Order
        """
        _no = Order(None)
        if market:
            _no.market = market
        return _no

    @classmethod
    def all(cls) -> Dict[int, Order]:
        """
        All the orders within current runtime/session

        :return: A dictionary of orders with order ID as key
        """
        return copy.copy(cls.__instances_by_id)

    @classmethod
    def current(cls) -> Dict[int, Order]:
        """
        The current "book" of available orders

        :return: A dictionary of current orders with order ID as key
        """
        return {id_: order for id_, order in cls.__instances_by_id.items() if order.is_pending}

    @classmethod
    def my_current(cls) -> Dict[int, Order]:
        """
        The current 'book' of available orders that belong to the current user

        :return: A dictionary of current self orders with order ID as key

        .. versionadded: 3.1.0
            Added returning only my current orders
        """
        return {id_: order for id_, order in cls.__instances_by_id.items() if order.is_pending and order.mine}

    @classmethod
    def trades_dict(cls) -> Dict[Order, Order]:
        """
        A dictionary of non-split, non-cancelled, consumed (subsumes non-split) orders

        :return: A dictionary of traded order pairs, where keys are original orders and values are fulfilling orders
        """
        return {order: order.traded_order for _, order in cls.__instances_by_id.items()
                if order.traded_order and order.date_created < order.traded_order.date_created}

    @classmethod
    def trades(cls, order_by: str = 'date_created', rev: bool = True) -> List[Tuple[Order, Order]]:
        """
        A list of non-split, non-cancelled, consumed (subsumes non-split) order pairs

        :param order_by: - an attribute of Order class for fulfilling order object, by which to sort the trades list
        :param rev: - whether to sort in reverse; default is True

        :return: A list of traded order pairs (tuple),
                 where first element is original order and second element is fulfilling order

        :raise AttributeError: If `order_by` attribute isn't available

        .. versionadded: 2.1.2
            Added trades as Dict

        .. versionchanged: 3.0
            Changed return type to List
        """
        if order_by not in cls.__enabled_attrs:
            raise AttributeError(f"Order object does not have attribute `{order_by}`")

        return sorted([(s_o, t_o) for s_o, t_o in cls.trades_dict().items()],
                      key=lambda t: getattr(t[1], order_by), reverse=rev)

    @classmethod
    def clear_all(cls) -> None:
        cls.__instances_by_id.clear()

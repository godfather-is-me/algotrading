"""
A marketplace entity with supporting classes
"""
from __future__ import annotations

import copy
from enum import Enum
from typing import Optional, Dict

from fmclient.utils.helper import string_to_local_date


class MarketplaceState(Enum):
    OPEN = 0
    PAUSED = 1
    CLOSED = 2


class Marketplace(object):
    """
    A Marketplace is the top level object representing a FM Marketplace.
    This would normally be used as a simple data store for information on a marketplace
    and some of the associated URLs

    In order to initialise this object, a dict with following keys need to be passed:
        ['id', 'createdDate', 'lastModifiedDate', 'name', 'description', '_links']

        '_links' is a dict with URLs for following:
            ['markets', 'sessions', 'accounts', 'currentSession']

    .. Note:: This class does **not** support :py:func:`copy` and :method:`deepcopy`
        from Python's :py:module:`copy` module.
    """

    fm_id: int
    name: str
    description: str

    __instances_by_id = {}
    __fields = {
        'id': ('fm_id', int),
        'createdDate': ('date_created', string_to_local_date),
        'lastModifiedDate': ('date_last_modified', string_to_local_date),
        'name': ('name', str),
        'description': ('description', str),
    }

    __urls = {
        'markets': ('url_markets', str),
        'sessions': ('url_sessions', str),
        'accounts': ('url_accounts', str),
        'currentSession': ('url_current_session', str),
    }

    __enabled_attrs = set([_[0] for _ in __fields.values()])
    __enabled_attrs.update([_[0] for _ in __urls.values()])
    _fields = tuple(__enabled_attrs)
    _field_defaults = {}

    # Add additional attributes
    __enabled_attrs.update('_id _locked'.split())
    _locked = False  # Relevant only for objects but not on class, however, it is required
    __print_fields = 'fm_id name'.split()

    def __new__(cls, id_, options: dict = None) -> Marketplace:
        if id_ not in cls.__instances_by_id:
            obj = super().__new__(cls)
            obj._locked = False
            obj._id = id_

            if options:
                for option, value in options.items():
                    if option in cls.__fields:
                        attr, type_ = cls.__fields[option]
                        obj.__setattr__(attr, type_(value))
                    elif option == '_links':
                        for opt_url, url in value.items():
                            if opt_url in cls.__urls:
                                attr, type_ = cls.__urls[opt_url]
                                obj.__setattr__(attr, type_(url['href']))

                obj._locked = True
                cls.__instances_by_id[id_] = obj

        try:
            return cls.__instances_by_id[id_]
        except KeyError:
            raise ValueError(f"Marketplace({id_}) does not exist")

    def __eq__(self, other):
        return self._id == other._id if isinstance(other, Marketplace) else False

    def __hash__(self):
        return hash(self._id)

    def __str__(self) -> str:
        info = ','.join([str(getattr(self, f)) for f in self.__print_fields if hasattr(self, f)])
        return f"Marketplace({info if info else self._id})"

    def __repr__(self) -> str:
        rep = ','.join(
            [':'.join([repr(f), repr(getattr(self, v[0]))]) for f, v in self.__fields.items() if hasattr(self, v[0])]
        )
        return f"Marketplace({self._id}, {{{rep}}})"

    def __getattr__(self, attr):
        if attr not in self.__enabled_attrs:
            raise AttributeError(attr)

        # Fetch a remote value here and return it
        if attr not in self.__dict__:
            raise AttributeError(attr)
        return self.__dict__[attr]

    def __setattr__(self, attr, value):
        if attr not in self.__enabled_attrs:
            raise AttributeError(attr)
        if self._locked:
            raise TypeError("'Marketplace' object cannot be modified after creation")

        # Set a remote value here
        self.__dict__[attr] = value

    @classmethod
    def get_by_id(cls, id_) -> Optional[Marketplace]:
        return cls.__instances_by_id.get(id_, None)

    @classmethod
    def all(cls) -> Dict[int, Marketplace]:
        return copy.copy(cls.__instances_by_id)

from enum import Enum


class FmCommand(Enum):
    OPEN = 'open'
    PAUSE = 'pause'
    CLOSE = 'close'

